package com.techpuzzle.keopi.data.firebase

import androidx.hilt.lifecycle.ViewModelInject
import androidx.paging.Pager
import androidx.paging.PagingConfig
import androidx.paging.cachedIn
import androidx.paging.liveData
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.techpuzzle.keopi.data.paging.FirestorePagingSource
import javax.inject.Inject

class FirebaseRepository @Inject constructor(
    private val firebaseFirestoreInstance: FirebaseFirestore
) {

    val caffeBarsCollection = firebaseFirestoreInstance.collection("kafici")

    fun getSearchResults(query: Query) =
        Pager(
            config = PagingConfig(
                pageSize = 3,
            ),
            pagingSourceFactory = { FirestorePagingSource(query) }
        ).flow

}