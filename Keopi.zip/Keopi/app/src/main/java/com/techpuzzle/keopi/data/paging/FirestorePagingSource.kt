package com.techpuzzle.keopi.data.paging

import android.util.Log
import androidx.compose.runtime.currentRecomposeScope
import androidx.hilt.lifecycle.ViewModelInject
import androidx.paging.PagingSource
import androidx.paging.PagingState
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.QuerySnapshot
import com.techpuzzle.keopi.data.entities.CaffeBar
import com.techpuzzle.keopi.data.firebase.FirebaseRepository
import kotlinx.coroutines.tasks.await
import java.io.IOException
import java.lang.IndexOutOfBoundsException
import javax.inject.Inject
import kotlin.math.log

class FirestorePagingSource(
    private var query: Query
) : PagingSource<QuerySnapshot, CaffeBar>() {

    private val TAG = "FirestorePagingSource"

    override suspend fun load(params: LoadParams<QuerySnapshot>): LoadResult<QuerySnapshot, CaffeBar> {
        return try {
            query = query.limit(3)

            val currentPage = params.key ?: query.get().await()
            Log.d(TAG, "current page: ${currentPage.size()}")

            val lastDocumentSnapshot = currentPage.documents[currentPage.size() - 1]

            val nextPage = query.startAfter(lastDocumentSnapshot).get().await()
            Log.d(TAG, "next page: ${nextPage.size()}")


            LoadResult.Page(
                data = currentPage.toObjects(CaffeBar::class.java),
                prevKey = null,
                nextKey = nextPage
            )

        } catch (e: IndexOutOfBoundsException) {
            val currentPage = params.key ?: query.get().await()

            LoadResult.Page(
                data = currentPage.toObjects(CaffeBar::class.java),
                prevKey = null,
                nextKey = null
            )
        }
    }

    override fun getRefreshKey(state: PagingState<QuerySnapshot, CaffeBar>): QuerySnapshot? = null
}