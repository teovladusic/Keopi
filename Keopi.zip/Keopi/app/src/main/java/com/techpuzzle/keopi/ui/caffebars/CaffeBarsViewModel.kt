package com.techpuzzle.keopi.ui.caffebars

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import androidx.paging.*
import com.google.firebase.firestore.Query
import com.techpuzzle.keopi.data.firebase.FirebaseRepository
import com.techpuzzle.keopi.data.paging.FirestorePagingSource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.*
import javax.inject.Inject

@HiltViewModel
class CaffeBarsViewModel @Inject constructor(
    private val firebaseRepository: FirebaseRepository
) : ViewModel() {

    private val caffeBarsEventsChannel = Channel<CaffeBarsEvents>()
    val caffeBarsEvents = caffeBarsEventsChannel.receiveAsFlow()

    val searchQuery = MutableStateFlow(" ")

    private val query = MutableStateFlow(
        firebaseRepository.caffeBarsCollection.limit(3)
    )

    @ExperimentalCoroutinesApi
    val caffeBarsFlow = combine(
        query,
        searchQuery
    ) { query2, searchQuery ->
        Pair(query2, searchQuery)
    }.flatMapLatest { (query, searchQuery) ->
        val newSearchQuery = if (searchQuery == "") " " else searchQuery
        Log.d("TAG","$query")
        getSearchResults(query.whereArrayContains("searchQuery", newSearchQuery))
            .cachedIn(viewModelScope)
    }

    private fun getSearchResults(query: Query) =
        Pager(
            config = PagingConfig(
                pageSize = 3,
            ),
            pagingSourceFactory = { FirestorePagingSource(query) }
        ).flow



    fun setKladomatQuery(contains: Boolean) {
        query.value = query.value.whereEqualTo("kladomat", contains)
    }


    sealed class CaffeBarsEvents {
        object RefreshData : CaffeBarsEvents()
    }
}