package com.techpuzzle.keopi.data.entities

data class CaffeBar(
    val adresa: String = "",
    val bio: String = "",
    val cjenikId: String = "",
    val id: String = "",
    val ime: String = "",
    val kapacitet: String = "",
    val kladomat: Boolean = false,
    val lokacija: String = "",
    val muzika: String = "",
    val prosjecnaDob: String = "",
    val pusenje: Boolean = false,
    val radnoVrijeme: String = "",
    val slika: String = "",
    val terasa: Boolean = false,
    val zabava: String = ""
)