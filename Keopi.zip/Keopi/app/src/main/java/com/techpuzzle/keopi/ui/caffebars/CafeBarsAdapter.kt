package com.techpuzzle.keopi.ui.caffebars

import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.compose.ui.text.TextRange
import androidx.paging.PagingDataAdapter
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.google.firebase.storage.FirebaseStorage
import com.techpuzzle.keopi.data.entities.CaffeBar
import com.techpuzzle.keopi.databinding.CafeBarItemBinding
import com.techpuzzle.keopi.glide.GlideApp
import com.techpuzzle.keopi.glide.GlideModule
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import javax.inject.Inject

class CafeBarsAdapter : PagingDataAdapter<CaffeBar, CafeBarsAdapter.CaffeBarViewHolder>(Companion) {

    lateinit var context: Context

    private val storage = FirebaseStorage.getInstance()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CaffeBarViewHolder {
        context = parent.context
        val binding = CafeBarItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return CaffeBarViewHolder(binding)
    }

    override fun onBindViewHolder(holder: CaffeBarViewHolder, position: Int) {
        val caffeBar = getItem(position) ?: return
        Log.d("TAG", "adapter ${caffeBar.ime}")
        holder.bind(caffeBar)
    }

    inner class CaffeBarViewHolder(
        private val binding: CafeBarItemBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(caffeBar: CaffeBar) {
            CoroutineScope(Dispatchers.Main).launch {
                val gsReference = storage.getReferenceFromUrl(caffeBar.slika)
                GlideApp.with(context)
                    .load(gsReference)
                    .into(binding.imageView)
            }
            binding.tvCaffeName.text = caffeBar.ime
            binding.tvWorkingTime.text = caffeBar.radnoVrijeme
            binding.tvLocation.text = caffeBar.lokacija
        }
    }

    companion object : DiffUtil.ItemCallback<CaffeBar>() {
        override fun areItemsTheSame(oldItem: CaffeBar, newItem: CaffeBar) =
            oldItem.id == newItem.id

        override fun areContentsTheSame(oldItem: CaffeBar, newItem: CaffeBar) = oldItem == newItem
    }
}