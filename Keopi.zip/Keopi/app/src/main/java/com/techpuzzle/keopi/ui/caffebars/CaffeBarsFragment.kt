package com.techpuzzle.keopi.ui.caffebars

import android.os.Bundle
import android.text.Html
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.View
import androidx.appcompat.widget.SearchView
import androidx.compose.runtime.structuralEqualityPolicy
import androidx.core.view.isVisible
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.paging.LoadState
import androidx.paging.flatMap
import androidx.paging.map
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.snackbar.Snackbar
import com.google.firebase.firestore.FirebaseFirestore
import com.techpuzzle.keopi.R
import com.techpuzzle.keopi.databinding.FragmentCaffebarsBinding
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

@AndroidEntryPoint
class CaffeBarsFragment : Fragment(R.layout.fragment_caffebars), SearchView.OnQueryTextListener {

    private var _binding: FragmentCaffebarsBinding? = null
    private val binding get() = _binding!!

    private val viewModel: CaffeBarsViewModel by viewModels()
    private val adapter = CafeBarsAdapter()

    @ExperimentalCoroutinesApi
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        _binding = FragmentCaffebarsBinding.bind(view)


        /*
        CoroutineScope(Dispatchers.IO).launch {
            //string = string
            val string = "Caffe Bar Aviva"
            val firebase = FirebaseFirestore.getInstance().collection("kafici")
                .document("xPCWDRzmh4aYnXsUHbNv")

            var allString = ""
            val array = mutableListOf<String>()
            string.forEach {
                allString += it
                array.add(allString.toLowerCase())
            }
            firebase.update("searchQuery", array)
        }
         */



        binding.apply {
            recViewCaffeBars.adapter = adapter
            recViewCaffeBars.layoutManager = LinearLayoutManager(requireContext())

            recViewPromoCaffes.apply {
                val caffes = listOf("Caffe Bar Shpitza", "Caffe Bar Cool", "Caffe Bar Faraon")
                val promoCaffesAdapter = PromoCaffesAdapter(caffes)

                adapter = promoCaffesAdapter
                layoutManager =
                    LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false)
            }

            searchViewCaffeBars.setOnQueryTextListener(this@CaffeBarsFragment)
        }

        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.caffeBarsFlow.collectLatest {
                adapter.submitData(it)
            }
        }

        adapter.addLoadStateListener {
            binding.progressBar.isVisible = it.refresh is LoadState.Loading
            binding.progressBar.isVisible = it.append is LoadState.Loading

            if (it.source.refresh is LoadState.NotLoading && adapter.itemCount < 1 && it.append.endOfPaginationReached) {
                binding.recViewCaffeBars.isVisible = false
                binding.tvNoResults.isVisible = true
            }else {
                binding.recViewCaffeBars.isVisible = true
                binding.tvNoResults.isVisible = false
            }

        }

    }

    override fun onQueryTextSubmit(query: String?) = false

    override fun onQueryTextChange(newText: String?): Boolean {
        newText?.let {
            viewModel.searchQuery.value = newText
        }
        return true
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

}