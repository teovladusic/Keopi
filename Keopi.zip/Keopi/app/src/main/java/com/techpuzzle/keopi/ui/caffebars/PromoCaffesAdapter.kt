package com.techpuzzle.keopi.ui.caffebars

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.techpuzzle.keopi.databinding.PromoCafeItemBinding

class PromoCaffesAdapter(
    val caffes: List<String>
) : RecyclerView.Adapter<PromoCaffesAdapter.PromoCaffesViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PromoCaffesViewHolder {
        val binding = PromoCafeItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return PromoCaffesViewHolder(binding)
    }

    override fun onBindViewHolder(holder: PromoCaffesViewHolder, position: Int) {
        val cafe = caffes[position]
        holder.binding.tvCafeName.text = cafe
    }

    override fun getItemCount() = caffes.size

    inner class PromoCaffesViewHolder(
        val binding: PromoCafeItemBinding
) : RecyclerView.ViewHolder(binding.root) {

    }
}